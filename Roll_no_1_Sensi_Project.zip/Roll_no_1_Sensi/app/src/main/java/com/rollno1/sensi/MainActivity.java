package com.rollno1.sensi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = 0xFF070B18, CARD = 0xFF101A30, CYAN = 0xFF36D9FF,
            WHITE = 0xFFF2F7FF, MUTED = 0xFF9AAAC7, GREEN = 0xFF5CFFA8;
    private LinearLayout root, content;
    private TextView stats;
    private Handler handler = new Handler(Looper.getMainLooper());
    private int particleTick = 0;
    private FloatingDot floatingDot;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        handler.post(statsUpdater);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF08152D, BG, 0xFF10102B}));
        setContentView(root);

        ScrollView scroll = new ScrollView(this);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content = new LinearLayout(this);
        content.setPadding(dp(18), dp(22), dp(18), dp(26));
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);

        TextView title = text("ROLL.NO.1 SENSI", 25, CYAN, true);
        content.addView(title);
        TextView sub = text("GAMING COMPANION  •  CONTROL DASHBOARD", 10, MUTED, true);
        sub.setPadding(0, dp(5), 0, dp(18));
        content.addView(sub);

        NeonCard hero = new NeonCard(this);
        hero.setPadding(dp(16), dp(17), dp(16), dp(17));
        content.addView(hero, paramsBottom(130, 14));
        hero.addView(text("MATRIX MODE", 12, GREEN, true));
        hero.addView(text("Your setup. Your profile.", 19, WHITE, true));
        TextView heroInfo = text("Save sensitivity profiles and monitor your device.", 12, MUTED, false);
        heroInfo.setPadding(0, dp(7), 0, 0);
        hero.addView(heroInfo);

        TextView profileHeader = section("SENSITIVITY PROFILE");
        content.addView(profileHeader);
        addSlider("General sensitivity", 180, 200);
        addSlider("Red Dot profile", 185, 200);
        addSlider("Fire button size", 48, 100);

        content.addView(section("DEMO FEATURE SWITCHES"));
        String[] demos = {"Regedit / Macro (demo)", "Auto-Headshot (demo)", "Aimbot / Aim Lock (demo)",
                "ESP Line / Box (demo)", "High Damage (demo)", "No Recoil (demo)"};
        for (String label : demos) addDemoSwitch(label);

        content.addView(section("DEVICE MONITOR"));
        stats = text("Reading device stats…", 13, WHITE, false);
        stats.setPadding(dp(14), dp(14), dp(14), dp(14));
        stats.setBackground(round(CARD, 16, 0xFF26395A, 1));
        content.addView(stats, paramsBottom(-2, 14));

        Button floatButton = button("ENABLE FLOATING BUTTON");
        content.addView(floatButton, paramsBottom(52, 10));
        floatButton.setOnClickListener(v -> enableFloating());
        Button save = button("SAVE PROFILE");
        content.addView(save, paramsBottom(48, 8));
        save.setOnClickListener(v -> {
            getPreferences(MODE_PRIVATE).edit()
                .putInt("general", sliders[0]).putInt("red", sliders[1]).putInt("fire", sliders[2]).apply();
            Toast.makeText(this, "Profile saved on this device", Toast.LENGTH_SHORT).show();
        });
        Button load = button("LOAD PROFILE");
        content.addView(load, paramsBottom(48, 8));
        load.setOnClickListener(v -> {
            android.content.SharedPreferences p = getPreferences(MODE_PRIVATE);
            int[] vals = {p.getInt("general",180), p.getInt("red",185), p.getInt("fire",48)};
            for (int i=0;i<seekBars.length;i++) seekBars[i].setProgress(vals[i]);
            Toast.makeText(this, "Profile loaded", Toast.LENGTH_SHORT).show();
        });
        TextView note = text("Demo switches only change this app's UI. They do not modify games or enable cheats.", 10, MUTED, false);
        note.setPadding(0, dp(12), 0, 0);
        content.addView(note);
    }

    private int[] sliders = {180,185,48};
    private SeekBar[] seekBars = new SeekBar[3];
    private void addSlider(String label, int value, int max) {
        int index = content.getChildCount();
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackground(round(CARD, 14, 0xFF1D3151, 1));
        content.addView(card, paramsBottom(-2, 9));
        TextView row = text(label + "   " + value, 13, WHITE, true);
        card.addView(row);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max); bar.setProgress(value);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));
        card.addView(bar);
        int si = seekIndex++;
        seekBars[si] = bar; sliders[si] = value;
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                sliders[si] = p; row.setText(label + "   " + p);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
    }
    private int seekIndex = 0;

    private void addDemoSwitch(String label) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(7), dp(9), dp(7));
        row.setBackground(round(CARD, 13, 0xFF1D3151, 1));
        LinearLayout.LayoutParams lp = paramsBottom(-2, 7);
        content.addView(row, lp);
        TextView name = text(label, 12, WHITE, true);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setShowText(false);
        sw.setButtonTintList(null);
        sw.setOnCheckedChangeListener((b, checked) ->
                Toast.makeText(this, label + (checked ? " ON (demo)" : " OFF"), Toast.LENGTH_SHORT).show());
        row.addView(sw);
    }

    private void enableFloating() {
        if (Settings.canDrawOverlays(this)) { showFloating(); return; }
        new AlertDialog.Builder(this).setTitle("Allow floating button")
                .setMessage("Android needs permission to show a movable button over other apps.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open settings", (d,w) -> {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }).show();
    }
    private void showFloating() {
        if (floatingDot != null) { Toast.makeText(this,"Floating button is already enabled",Toast.LENGTH_SHORT).show(); return; }
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        floatingDot = new FloatingDot(this);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(dp(58), dp(58),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START; p.x = dp(20); p.y = dp(180);
        floatingDot.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy, wx, wy; long down;
            public boolean onTouch(View v, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx=(int)e.getRawX(); sy=(int)e.getRawY(); wx=p.x; wy=p.y; down=System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE: p.x=wx+(int)e.getRawX()-sx; p.y=wy+(int)e.getRawY()-sy; wm.updateViewLayout(floatingDot,p); return true;
                    case MotionEvent.ACTION_UP:
                        if(System.currentTimeMillis()-down<250) {
                            Toast.makeText(MainActivity.this,"Roll.no.1 Sensi • Tap to open dashboard",Toast.LENGTH_SHORT).show();
                        } return true;
                } return false;
            }
        });
        wm.addView(floatingDot,p);
        Toast.makeText(this,"Floating button enabled. Drag to move it.",Toast.LENGTH_LONG).show();
    }

    private final Runnable statsUpdater = new Runnable() {
        public void run() {
            if (stats != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
                long used = mi.totalMem - mi.availMem;
                BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
                int battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                stats.setText(String.format(Locale.getDefault(),
                        "RAM used: %.2f / %.2f GB\\nRAM available: %.2f GB\\nBattery: %s%%\\nAndroid: %s",
                        used/1073741824.0, mi.totalMem/1073741824.0, mi.availMem/1073741824.0,
                        battery >= 0 ? String.valueOf(battery) : "N/A", android.os.Build.VERSION.RELEASE));
            }
            handler.postDelayed(this, 2500);
        }
    };

    private TextView section(String s) {
        TextView t = text(s, 12, CYAN, true);
        t.setPadding(0, dp(17), 0, dp(9));
        return t;
    }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(12);
        b.setBackground(round(0xFF102745, 14, CYAN, 1)); return b;
    }
    private LinearLayout.LayoutParams paramsBottom(int height, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(height));
        p.bottomMargin = dp(bottom); return p;
    }
    private GradientDrawable round(int color, int radius, int stroke, int width) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(width), stroke); return d;
    }
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() { super.onResume(); if (Settings.canDrawOverlays(this)) { /* permission ready */ } }
    @Override protected void onDestroy() {
        handler.removeCallbacks(statsUpdater);
        if (floatingDot != null) {
            try { ((WindowManager)getSystemService(WINDOW_SERVICE)).removeView(floatingDot); } catch (Exception ignored) {}
            floatingDot = null;
        }
        super.onDestroy();
    }

    private class NeonCard extends LinearLayout {
        Paint glow = new Paint(3);
        NeonCard(Context c) { super(c); setOrientation(VERTICAL); setBackground(round(0xE610203B,18,CYAN,1)); }
    }
    private class FloatingDot extends View {
        Paint p = new Paint(3);
        FloatingDot(Context c) { super(c); }
        protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setColor(0x5536D9FF); c.drawCircle(w/2,h/2,w*.48f,p);
            p.setColor(0xFF0D2340); c.drawCircle(w/2,h/2,w*.40f,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(CYAN);
            c.drawCircle(w/2,h/2,w*.38f,p); p.setStyle(Paint.Style.FILL);
            p.setColor(WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(15));
            c.drawText("R1",w/2-p.measureText("R1")/2,h/2+dp(5),p);
        }
    }
}
