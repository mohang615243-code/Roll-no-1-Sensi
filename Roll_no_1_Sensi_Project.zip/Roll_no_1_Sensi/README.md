# Roll.no.1 Sensi

A native Android Java starter project with a dark neon dashboard, sensitivity profile sliders, demo-only feature switches, RAM/battery monitoring, and an optional draggable floating button.

## Build
This project uses Android Gradle Plugin 8.9.2 and compile SDK 35. It requires Android SDK Platform 35 and Build Tools installed.

From a machine with Android SDK and a compatible Gradle version:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

Note: Termux's Gradle 9.6 may not be compatible with Android Gradle Plugin 8.9.2. A compatible Gradle 8.11.1 distribution is recommended. You can build in Android Studio or use a compatible Gradle installation.

The floating button requires the user to grant Android's “Display over other apps” permission. Demo switches are UI-only and do not alter games or enable cheats.
